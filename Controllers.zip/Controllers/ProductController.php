<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ProductController extends Controller
{
    /**
     * Display a listing of all products.
     *
     * - Fetches all records from the `products` table using raw SQL.
     * - Passes the products to the `products.index` view.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        $products = DB::select("SELECT * FROM products");
        return view('products.index', compact('products'));
    }

    /**
     * Show the form to create a new product.
     *
     * - Simply returns the `products.create` view.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {
        return view('products.create');
    }

    /**
     * Store a newly created product in the database.
     *
     * - Handles image upload (if provided) and stores it in `public/uploads`.
     * - Inserts product details (name, price, quantity, category, image) into the `products` table.
     * - Redirects to the product list with a success message.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(Request $request)
    {
        $imageName = null;
        if ($request->hasFile('image')) {
            $imageName = time() . '.' . $request->image->extension();
            $request->image->move(public_path('uploads'), $imageName);
        }

        DB::insert("INSERT INTO products (name, price, quantity, category, image) VALUES (?, ?, ?, ?, ?)", [
            $request->name, $request->price, $request->quantity, $request->category, $imageName
        ]);

        return redirect()->route('products.index')->with('success', 'Product added!');
    }

    /**
     * Show the form to edit an existing product.
     *
     * - Fetches the product by ID from the `products` table.
     * - Passes the product to the `products.edit` view.
     *
     * @param int $id
     * @return \Illuminate\View\View
     */
    public function edit($id)
    {
        $product = DB::select("SELECT * FROM products WHERE id = ?", [$id]);
        return view('products.edit', ['product' => $product[0]]);
    }

    /**
     * Update an existing product in the database.
     *
     * - If a new image is uploaded, replaces the old image and saves it in `public/uploads`.
     * - If no new image is uploaded, keeps the old image.
     * - Updates product details (name, price, quantity, category, image) in the `products` table.
     * - Redirects to the product list with a success message.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(Request $request, $id)
    {
        $imageName = $request->old_image;
        if ($request->hasFile('image')) {
            $imageName = time() . '.' . $request->image->extension();
            $request->image->move(public_path('uploads'), $imageName);
        }

        DB::update("UPDATE products SET name=?, price=?, quantity=?, category=?, image=? WHERE id=?", [
            $request->name, $request->price, $request->quantity, $request->category, $imageName, $id
        ]);

        return redirect()->route('products.index')->with('success', 'Product updated!');
    }

    /**
     * Remove a product from the database.
     *
     * - Deletes the product record from the `products` table by ID.
     * - Redirects to the product list with a success message.
     *
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function delete($id)
    {
        DB::delete("DELETE FROM products WHERE id = ?", [$id]);
        return redirect()->route('products.index')->with('success', 'Product deleted!');
    }
}
