<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use App\Models\User;

class AuthController extends Controller
{
    // Show Register Page
    public function showRegister()
    {
        return view('auth.register');
    }

    // Handle Register - FIXED VERSION
    public function register(Request $request)
    {
        // Validation
        $request->validate([
            'name' => 'required|string|max:100',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|confirmed|min:6',
            'profile_picture' => 'nullable|image|mimes:jpg,jpeg,png,gif|max:2048',
        ]);

        // Handle profile picture upload - FIXED
        $profileImage = null;
        if ($request->hasFile('profile_picture')) {
            $file = $request->file('profile_picture');
            
            // Generate a unique filename
            $profileImage = time() . '_' . uniqid() . '.' . $file->getClientOriginalExtension();
            
            // DEBUG: Check if file is valid
            if (!$file->isValid()) {
                return back()->withErrors(['profile_picture' => 'Invalid file uploaded.'])->withInput();
            }
            
            // Create profiles directory if it doesn't exist
            $profilesPath = public_path('profiles');
            if (!file_exists($profilesPath)) {
                mkdir($profilesPath, 0755, true);
            }
            
            // Move the file to the public/profiles directory
            try {
                $file->move($profilesPath, $profileImage);
            } catch (\Exception $e) {
                // If file upload fails, proceed without profile picture
                $profileImage = null;
                // You can log the error if needed
                // \Log::error('Profile picture upload failed: ' . $e->getMessage());
            }
        }

        // Create user
        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'profile_picture' => $profileImage,
        ]);

        // Log the user in
        Auth::login($user);

        return redirect()->route('products.index')->with('success', 'Registration successful!');
    }

    // Show Login Page
    public function showLogin()
    {
        return view('auth.login');
    }

    // Handle Login
    public function login(Request $request)
    {
        $credentials = $request->validate([
            'email' => 'required|email',
            'password' => 'required'
        ]);

        if (Auth::attempt($credentials)) {
            $request->session()->regenerate();
            return redirect()->route('products.index')->with('success', 'Login successful!');
        }

        return back()->withErrors([
            'email' => 'The provided credentials do not match our records.',
        ])->onlyInput('email');
    }

    // Logout
    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return redirect()->route('login.show')->with('success', 'You have been logged out successfully!');
    }

    // Update Password
    public function updatePassword(Request $request)
    {
        $request->validate([
            'current_password' => 'required',
            'new_password' => 'required|confirmed|min:6',
        ]);

        if (!Hash::check($request->current_password, Auth::user()->password)) {
            return back()->withErrors(['current_password' => 'Current password is incorrect']);
        }

        Auth::user()->update([
            'password' => Hash::make($request->new_password),
        ]);

        return back()->with('success', 'Password updated successfully!');
    }
}