<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ProductController extends Controller
{
    // Show all products
    public function index()
    {
        $products = DB::select("SELECT * FROM products");
        return view('products.index', compact('products'));
    }

    // Show form to create
    public function create()
    {
        return view('products.create');
    }

    // Store product
    public function store(Request $request)
    {
        // file upload
        $imageName = null;
        if ($request->hasFile('image')) {
            $imageName = time() . '.' . $request->image->extension();
            $request->image->move(public_path('uploads'), $imageName);
        }

        DB::insert("INSERT INTO products (name, price, quantity, category, image) VALUES (?, ?, ?, ?, ?)", [
            $request->name, $request->price, $request->quantity, $request->category, $imageName
        ]);

        return redirect()->route('products.index')->with('success', 'Product added!');
    }

    // Edit form
    public function edit($id)
    {
        $product = DB::select("SELECT * FROM products WHERE id = ?", [$id]);
        return view('products.edit', ['product' => $product[0]]);
    }

    // Update product
    public function update(Request $request, $id)
    {
        $imageName = $request->old_image; // keep old image if new not uploaded
        if ($request->hasFile('image')) {
            $imageName = time() . '.' . $request->image->extension();
            $request->image->move(public_path('uploads'), $imageName);
        }

        DB::update("UPDATE products SET name=?, price=?, quantity=?, category=?, image=? WHERE id=?", [
            $request->name, $request->price, $request->quantity, $request->category, $imageName, $id
        ]);

        return redirect()->route('products.index')->with('success', 'Product updated!');
    }

    // Delete product
    public function delete($id)
    {
        DB::delete("DELETE FROM products WHERE id = ?", [$id]);
        return redirect()->route('products.index')->with('success', 'Product deleted!');
    }
}
