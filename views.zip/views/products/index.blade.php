<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Product Inventory</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
  <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <style>
    body {
      overflow-x: hidden;
      background: #f8f9fa;
    }
    /* Sidebar */
    .sidebar {
      position: fixed;
      top: 0; left: -260px;
      width: 260px;
      height: 100%;
      background: #09bc50ff;
      color: white;
      transition: all 0.3s ease;
      padding: 20px;
      z-index: 1050;
    }
    .sidebar.active { left: 0; }
    .sidebar .profile-pic {
      width: 100px; height: 100px;
      object-fit: cover; border-radius: 50%;
      margin: 0 auto 10px auto; display: block;
      border: 3px solid #ffc107;
    }
    .sidebar h4, .sidebar p { text-align: center; margin: 5px 0; }
    .sidebar .nav-link {
      color: #ffc107; display: flex;
      align-items: center; gap: 10px;
      margin: 10px 0; font-size: 15px;
    }
    .sidebar .nav-link:hover { color: #fff; }
    /* Overlay */
    .overlay {
      position: fixed; top: 0; left: 0;
      width: 100%; height: 100%;
      background: rgba(0,0,0,0.5);
      display: none; z-index: 1040;
    }
    .overlay.active { display: block; }
    /* Hamburger */
    .hamburger {
      position: fixed;
      top: 15px; left: 15px;
      font-size: 28px; cursor: pointer;
      z-index: 1100; color: #212529;
    }
    /* Main Content */
    .content {
      max-width: 1100px;
      margin: 30px auto;
      padding: 20px;
    }
  </style>
</head>
<body>

  <!-- Hamburger -->
  <div class="hamburger"><i class="bi bi-list"></i></div>

  <!-- Sidebar -->
  <div class="sidebar">
    <div class="text-center mb-3">
      @if(Auth::user()->profile_picture)
        <img src="{{ asset('profiles/' . Auth::user()->profile_picture) }}" alt="Profile" class="profile-pic">
      @else
        <img src="https://via.placeholder.com/100" alt="Profile" class="profile-pic">
      @endif
      <h4>{{ Auth::user()->name }}</h4>
      <p class="text-muted small">{{ Auth::user()->email }}</p>
    </div>
    <hr class="bg-light">
    <a href="#" class="nav-link" data-bs-toggle="modal" data-bs-target="#changePasswordModal">
      <i class="bi bi-shield-lock-fill"></i> Change Password
    </a>
    <a href="{{ route('logout') }}" class="nav-link">
      <i class="bi bi-box-arrow-right"></i> Logout
    </a>
  </div>

  <!-- Overlay -->
  <div class="overlay"></div>

  <!-- Main Content -->
  <div class="content">
    <!-- Alerts -->
    @if(session('success'))
      <div class="alert alert-success">{{ session('success') }}</div>
    @endif
    @if(session('error'))
      <div class="alert alert-danger">{{ session('error') }}</div>
    @endif

    <div class="d-flex justify-content-between align-items-center mb-3">
      <h2 class="fw-bold">📦 Product Inventory</h2>
      <a href="{{ route('products.create') }}" class="btn btn-success">
        <i class="bi bi-plus-circle"></i> Add Product
      </a>
    </div>

    <div class="card shadow-sm">
      <div class="card-body">
        <table class="table table-bordered table-hover text-center align-middle">
          <thead class="table-dark">
            <tr>
              <th>ID</th><th>Name</th><th>Price</th><th>Qty</th>
              <th>Category</th><th>Image</th><th>Actions</th>
            </tr>
          </thead>
          <tbody>
            @foreach($products as $p)
              <tr>
                <td>{{ $p->id }}</td>
                <td>{{ $p->name }}</td>
                <td>Rs.{{ number_format($p->price,2) }}</td>
                <td>{{ $p->quantity }}</td>
                <td>{{ $p->category }}</td>
                <td>
                  @if($p->image)
                    <img src="{{ asset('uploads/'.$p->image) }}" width="60" class="rounded img-thumbnail">
                  @else
                    <span class="text-muted">No Image</span>
                  @endif
                </td>
                <td>
                  <a href="{{ route('products.edit',$p->id) }}" class="btn btn-sm btn-primary">
                    <i class="bi bi-pencil-square"></i>
                  </a>
                  <a href="{{ route('products.delete',$p->id) }}" class="btn btn-sm btn-danger delete-btn">
                    <i class="bi bi-trash"></i>
                  </a>
                </td>
              </tr>
            @endforeach
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- Modal: Change Password -->
  <div class="modal fade" id="changePasswordModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
      <form method="POST" action="{{ route('password.update') }}" class="modal-content">
        @csrf
        <div class="modal-header">
          <h5 class="modal-title">Change Password</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
              <label>Current Password</label>
              <input type="password" class="form-control" name="current_password" required>
          </div>
          <div class="mb-3">
              <label>New Password</label>
              <input type="password" class="form-control" name="new_password" required>
          </div>
          <div class="mb-3">
              <label>Confirm New Password</label>
              <input type="password" class="form-control" name="new_password_confirmation" required>
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-success">Update Password</button>
        </div>
      </form>
    </div>
  </div>

  <script>
    $(function(){
      $(".hamburger, .overlay").click(function(){
        $(".sidebar, .overlay").toggleClass("active");
      });
      $(".delete-btn").click(function(e){
        if(!confirm("Are you sure you want to delete this product?")) e.preventDefault();
      });
    });
  </script>

</body>
</html>
