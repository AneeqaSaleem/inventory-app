<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #e0eafc 0%, #cfdef3 100%);
        }
        .card {
            border-radius: 18px;
            box-shadow: 0 8px 32px rgba(44, 62, 80, 0.12);
            animation: fadeInUp 0.8s;
        }
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(40px);}
            to { opacity: 1; transform: translateY(0);}
        }
        .login-anim-icon {
            font-size: 60px;
            color: #267abeff;
            animation: swing 1.5s infinite alternate;
            display: inline-block;
            margin-bottom: 10px;
        }
        @keyframes swing {
            0% { transform: rotate(-10deg);}
            100% { transform: rotate(10deg);}
        }
        .input-group-text {
            background: #1c1aaeff;
            color: #fff;
            border: none;
        }
        .form-control:focus {
            box-shadow: 0 0 0 2px #7c6bc433;
            border-color: #2f0e92ff;
        }
        .btn-primary {
            background: #4d18e0ff;
            border: none;
            font-weight: 500;
            letter-spacing: 1px;
        }
        .btn-primary:hover {
            background: #2216a8ff;
        }
        .btn-link {
            color: #0e1e98ff;
            text-decoration: none;
        }
        .btn-link:hover {
            text-decoration: underline;
            color: #4218c0ff;
        }
        .card-header {
            background: #0a0c83ff;
            color: #fff;
            border-radius: 18px 18px 0 0;
        }
        .alert-danger {
            font-size: 15px;
            padding: 6px 12px;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>

<div class="container mt-5">
    <div class="card shadow-lg" style="max-width:400px; margin:auto;">
        <div class="card-header text-center">
            <span class="login-anim-icon"><i class="bi bi-shield-lock-fill"></i></span>
            <h3 class="mb-0 mt-2">Login</h3>
        </div>
        <div class="card-body">
            <form method="POST" action="{{ route('login') }}">
                @csrf
                <div class="mb-3 input-group">
                    <span class="input-group-text"><i class="bi bi-envelope-fill"></i></span>
                    <input type="email" class="form-control" name="email" placeholder="Email Address" required>
                </div>
                <div class="mb-3 input-group">
                    <span class="input-group-text"><i class="bi bi-lock-fill"></i></span>
                    <input type="password" class="form-control" name="password" placeholder="Password" required>
                </div>
                @error('email')
                    <div class="alert alert-danger">{{ $message }}</div>
                @enderror
                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-primary"><i class="bi bi-box-arrow-in-right"></i> Login</button>
                    <a href="{{ route('register.show') }}" class="btn btn-link"><i class="bi bi-person-plus"></i> Create new account</a>
                </div>
            </form>
        </div>